#!/usr/bin/python3

import os
import shutil
import subprocess
import time
import re
import traceback
import sys
import heapq
import math


from enum import Enum
from sys import argv


def copyfile(src,dst):
  try:
    os.remove(dst)    
  except FileNotFoundError:
    pass
  except:
    raise
  shutil.copy(src,dst)

# Kill the script if it runs longer than this many seconds
TIMELIMIT = 200

# Run 'python' on Windows, 'python3' for Unix
WINDOWS = (sys.platform == "win32")
EXE = "python" if WINDOWS else "python3"

TMP_SCRIPT = 'tmp_script_wrapper.py'

# Fix unicode quotes
def wrap_student_code(script_name):
  with open(script_name, 'r', encoding='utf-8') as s_in, open(TMP_SCRIPT, 'w') as s_out:
    for line in s_in:
      line = line.replace('\u2019', '\\\'')  # Remove unicode quotes
      line = line.replace('\uff09', '')  
      s_out.write(line)

# Shell colours
class bcolors:
  NOCOMP = '\033[95m'
  OKBLUE = '\033[94m'
  OKGREEN = '\033[92m'
  WARNING = '\033[93m'
  FAIL = '\033[91m'
  ENDC = '\033[0m'
  BOLD = '\033[1m'
  UNDERLINE = '\033[4m'

def getValue(aList,string):
  string = string.lower()
  value = -1
  for line in aList:
    line = line.lower()
    if string in line:
      if value != -1:
        print("Warning: Multiple lines for",string)
        return -2
      line = line.split(":")
      value = int(line[1].strip())
  if value == -1:
    print("Warning: I couldn't find a value for",string)
  return value

def getValues(aList):
  values = []
  values.append(getValue(aList,"total price"))
  values.append(getValue(aList,"total items"))
  values.append(getValue(aList,"total profit"))
  return values
  
# Execution results
class Result(Enum):
  OK = 1
  TLE = 2
  RE = 3
  
    
# -----------------------------------------------------------------------------
#                         Testing base class
# -----------------------------------------------------------------------------
class Tester:
  def __init__(self, script, sample, inputfile, testdir):
    
    self.script_name = script
    self.sample_script = sample
    self.input_file = inputfile
    self.test_dir = testdir

  def execute(self,code):
    if code == "student":
      wrap_student_code(self.script_name)
    else:
      wrap_student_code(self.sample_script)
    exe_name = '{:s} {:s}'.format(EXE, TMP_SCRIPT)
    process = subprocess.Popen(exe_name, stdin=open('test.in', 'r'), stdout=open(code+'_test.out', 'w'), stderr=open(code+'_test.err', 'w'), shell=True)
    start = time.clock()
    while time.clock() - start < TIMELIMIT:
      if process.poll() != None: break
    exec_time = min(TIMELIMIT, time.clock() - start)
    if process.poll() == None:
      process.terminate()
      return Result.TLE, process.returncode, exec_time
    elif not process.returncode == 0:
      return Result.RE, process.returncode, exec_time
    else:
      return Result.OK, process.returncode, exec_time
    
  def run(self, inputfile,  code):
    copyfile(inputfile, self.input_file)
    
    res, retcode, exec_time = self.execute(code)
    if res == Result.RE:
      print('Runtime Error in '+code+' code', 'Program script crashed on input file {:s} with return code: {:d}'.format(inputfile, retcode))
      self.dump_stderr(code)
      
    elif res == Result.TLE:
      print('Time Limit error in'+code+' code', 'Program ran for {:.2f} seconds without terminating'.format(TIMELIMIT))
      self.dump_output(output,code)
      
        
    return res, retcode, open(code+'_test.out', 'r'), exec_time
       
       
  def dump_output(self, output, code):
    print('The '+code+' output was::')
    print('############################')
    output.seek(0, 0)
    i = 0
    for line in output:
      printline = line.rstrip()
      if len(printline) > 200: printline = printline[:200] + '...'   # Cap output size at 200 characters...
      print('\t{:s}'.format(printline))
      i += 1
      if i > 20:                                                     # Cap output size at 20 lines...
        print('\t...')
        break
    print('############################\n\n')
       
  def dump_stderr(self,code):
    print("Contents of stderr for "+code+" code:")
    print('############################')
    with open(code+'_test.err', 'r') as err_in:
      for line in err_in:
        print('\t{:s}'.format(line.rstrip()))
    print('############################')

  def readIntoList(self,output):
    aList = []
    for line in output.readlines():
      
      line = line.strip()
      if line != "":
        aList.append(line)
    return aList

  def verifyItems(self,aList,values):
    infile = open(self.input_file)
    products = []
    for line in infile:
      line = line.strip()
      line = line.split(":")
      ID = int(line[0])
      assert(ID == len(products))
      products.append([line[1],int(line[2]),int(line[3])])

    totalPrice = 0
    totalProfit = 0
    totalItems = 0
    

    for line in aList:
      if "[" in line and "]" in line:
        line = line.split("X")
        quantity = int(line[0].strip())
        
        item = line[1]
        item = item.strip()
        item = item.strip("[")
        item = item.strip("]")
        item = item.split(":")
        ID = int(item[0])
        name = item[1]
        price = int(item[2])
        profit = int(item[3])
        if products[ID][0] != name:
          print("Incorrect name for product with ID",ID)
          return False
        if products[ID][1] != price:
          print("Incorrect price per item for product with ID",ID,"- Actual price:", products[ID][1]," You listed:",price)
          return False
        if products[ID][2] != profit:
          print("Incorrect profit per item for product with ID",ID)
          return False

        
        totalItems += quantity
        totalPrice += quantity*price
        totalProfit += quantity*profit
        

    
    if values[0] != totalPrice:
      print("Total price of these items do not match with the total price you listed")
      return False
    if values[2] != totalProfit:
      print("Total profit of these items do not match with the total profit you listed")
      return False
    
    if values[1] != totalItems:
      print("Total number of items do not match with the total items you listed")
      return False
    return True
  
  def verify(self, output, sample_output, inputs):
    outList = self.readIntoList(output)
    sampleList = self.readIntoList(sample_output)

    PRICE = 0
    ITEMS = 1
    PROFIT = 2
    valid = True

    price_limit = inputs[PRICE]
    item_limit = inputs[ITEMS]

    if item_limit == "infinity":
      item_limit = math.inf
      
      
    student_values = getValues(outList)
    sample_values = getValues(sampleList)

    
    if student_values[PRICE] > price_limit:
      print("Total price of items you sold is greater than the price limit", price_limit)
      valid = False
    if student_values[ITEMS] > item_limit:
      print("Total number of items you sold is greater than the item limit", item_limit)
      valid = False
    if student_values[PROFIT] != sample_values[PROFIT]:
      print("Total profit does not match the sample output. Your profit:",student_values[PROFIT], "Sample profit:", sample_values[PROFIT])
      valid = False
    else:
      
      # another sanity check
      if not self.verifyItems(outList,student_values):
        valid = False

      # check sample output as well (just in case)
      if not self.verifyItems(sampleList,sample_values):
        valid = False

    return valid
       
  def test(self):
    if not os.path.exists(self.script_name):
      print('Error', 'No script with filename {:s} found'.format(self.script_name))
      return
  
    files = os.listdir(self.test_dir)
    files.sort()

    inputs = [[1500,"infinity"],[50,"infinity"],[750,"infinity"],[3300,"infinity"],[1500,24],[50,4],[750,20],[3300,30]]
    #inputs = [[1500,24]]
    # Run all input files
    for file in files:
      if file.endswith("products.txt"):
        #print('-------------------------------------------------------------------')
        #print('\t\t\t{:s}'.format(os.path.basename(file)))
        #print('-------------------------------------------------------------------')
        
        filepath = os.path.join(self.test_dir, file)
        i = 1
        for vals in inputs: # run for each input value
          print('\n\n-------------------------------------------------------------------')
          print("   Test "+str(i)+": price limit:",vals[0], "item limit:", vals[1])
          print('-------------------------------------------------------------------\n\n')
        
          
          i+=1
          valuesFile = open("test.in","w")
          for v in vals:
            valuesFile.write(str(v)+"\n")
          valuesFile.close()
          
          result, retcode, output, exec_time = self.run(filepath,  "student")
          sample_result, sample_retcode, sample_output, sample_exec_time = self.run(filepath, "sample")

          if result == Result.RE or sample_result == Result.RE:
            print("Runtime error by student or sample code. See student_test.err and sample_test.err")
          elif result == Result.TLE or sample_result == Result.TLE:
            print("Time limit exceeded for student or sample code")
          else:
            try:
              if self.verify(output, sample_output,vals):
                print("\nCorrect output!!!")
                
               
              else:
                print("Output did not match. For more details, compare the files student_test.out (generated by your code) and sample_test.out (generated by sample solution)")
                self.dump_output(output,"student")
                self.dump_output(sample_output,"sample")
            except Exception:
              print('Bad output', 'Judge crashed while trying to validate answer')
              self.dump_output(output,"student")
              self.dump_output(sample_output,"sample")
              traceback.print_exc()
          output.close()
          sample_output.close()
    
    
         
if __name__ == "__main__":

  # Create tester
  folder = "tests"
  current_path = os.path.dirname(os.path.realpath(__file__))
  os.chdir(current_path)
  dir = os.path.join(current_path, folder)
  test1 = Tester("ebay.py", "sample.py", "products.txt",  dir)
  test1.test()
  
