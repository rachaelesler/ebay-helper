




def solve_task1(product_list, price_limit):
    None
    # write your solution for the task 1 here.
    # feel free to create and utilize functions as required


def solve_task2(product_list, price_limit, item_limit):
    # write your solution for the task 1 here.
    # feel free to create and utilize functions as required
    None


#####################################################
# DO NOT CHANGE/WRITE ANYTHING BELOW THIS LINE
#####################################################

# This function prints the results in the required format.
# to_sell is a list of lists representing the products to be sold. Each item in to_sell is a list where item[1] is the product ID and item[0] is the quanity of the product.
def print_solution(to_sell,product_list):
    total_items, total_price, total_profit = 0, 0, 0
    for value in to_sell:
        quantity = value[0]
        product = product_list[value[1]]
        print(str(quantity)+" X ["+str(value[1])+":"+product[1]+":"+str(product[2])+":"+str(product[3])+"]")
        total_items += quantity
        total_price += product[2]*quantity
        total_profit += product[3]*quantity
        
    print("Total items sold:",total_items)
    print("Total price of items sold:",total_price)
    print("Total profit of items sold:",total_profit)

        
def load_sample_solutions(file):
    solutions = []
    i = 0
    thisSolution = []
    for line in file:
        line = line.strip()
        if line == "": # last line may be empty
            continue
        
        line = line.split(":")
        if line[0] == "parameters":
            if i != 0:
                solutions.append(thisSolution)
            thisSolution = [[line[1],line[2]]]
            i+=1
        else:
            thisSolution.append([int(line[0]),int(line[1])])
    solutions.append(thisSolution)
    return solutions
    print(solutions)
            
            

def get_solution(price_limit,item_limit,sample_solutions):
    for solution in sample_solutions:
        
        if solution[0] == [price_limit,item_limit]:
            
            to_sell = []
            for i in range(1,len(solution)):
                to_sell.append(solution[i])
            print_solution(to_sell,product_list)
        

input_file = open("products.txt")
product_list = []

i=0
for line in input_file:
    line = line.strip()
    line = line.split(":")
    product_list.append([i,line[1],int(line[2]),int(line[3])])
    i+=1


sample_file = open("sample_output.txt")
sample_solutions = load_sample_solutions(sample_file)

    
    
price_limit = input("Enter the price limit: ")
print() # the sample solution shown in assignment sheet doesn't have an extra line. But don't worry about it. This is required for the tester. Do not remove this.
item_limit = input("Enter the item limit: ")
print()


get_solution(price_limit,item_limit,sample_solutions)
